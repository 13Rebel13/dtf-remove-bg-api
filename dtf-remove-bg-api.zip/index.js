
const express = require('express');
const axios = require('axios');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 10000;

app.use(cors());
app.use(bodyParser.json({ limit: '10mb' }));

app.post('/remove-bg', async (req, res) => {
  const { imageBase64 } = req.body;

  if (!imageBase64) {
    return res.status(400).json({ error: 'Aucune image reçue' });
  }

  try {
    const response = await axios.post('https://sdk.photoroom.com/v1/segment', {
      image_file_b64: imageBase64
    }, {
      headers: {
        'x-api-key': process.env.PHOTOROOM_API_KEY,
        'Content-Type': 'application/json'
      }
    });

    const resultImage = response.data?.image;

    if (!resultImage) {
      return res.status(500).json({ error: 'Réponse invalide de l'API Photoroom' });
    }

    res.json({ image: resultImage });
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: 'Erreur interne lors de l’appel à Photoroom' });
  }
});

app.listen(port, () => {
  console.log(`Serveur API remove-bg en ligne sur le port ${port}`);
});
